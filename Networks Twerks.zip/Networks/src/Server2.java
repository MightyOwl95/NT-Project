import java.io.*;
import java.net.*;

class Server2 {
	public static void main(String argv[]) throws Exception {
		int port = 6000;
		String clientSentence;
		String capitalizedSentence;
		ServerSocket welcomeSocket = new ServerSocket(port);
		while (true) {

			Socket connectionSocket = welcomeSocket.accept();
			BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
			DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());
			PrintWriter pwrite = new PrintWriter(outToClient, true);
			
			while (true) {
				if ((clientSentence = inFromClient.readLine()) != null) {
					if (clientSentence.equalsIgnoreCase("bye") || clientSentence.equalsIgnoreCase("quit")){
						connectionSocket.close();
						System.out.println();
						System.out.println("Server is awaiting new clients");
						break;
						
					}
					System.out.println(clientSentence);
				}
				//sendMessage = "Server: " + keyRead.readLine();
				pwrite.println(clientSentence);
				pwrite.flush();
			}
			
			
			
			/*
			capitalizedSentence = clientSentence.toUpperCase() + '\n';
			outToClient.writeBytes(clientSentence + '\n');*/
		}
	}
}