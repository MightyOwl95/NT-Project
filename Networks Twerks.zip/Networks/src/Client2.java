import java.io.*;
import java.net.*;

class Client2 {
	public static void main(String argv[]) throws Exception {
		int port = 6000;
		String sentence;
		String modifiedSentence;

		Socket clientSocket = new Socket("192.168.0.134", port);
		BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
		DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
		PrintWriter pwrite = new PrintWriter(outToServer, true);
		BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
		sentence = inFromUser.readLine();
		/*
		 * outToServer.writeBytes(sentence + '\n'); modifiedSentence =
		 * inFromServer.readLine(); System.out.println("FROM SERVER: " +
		 * modifiedSentence);
		 */

		String receiveMessage, sendMessage;

		while (true) {
			sendMessage = inFromUser.readLine();
			pwrite.println(sendMessage);
			pwrite.flush();
			if ((receiveMessage = inFromServer.readLine()) != null) {
				System.out.println(receiveMessage);
			}
			if (sendMessage.equalsIgnoreCase("bye") || sendMessage.equalsIgnoreCase("quit")) {
				System.out.println(" disconnected");
				clientSocket.close();
				break;

			}

		}

	}
}