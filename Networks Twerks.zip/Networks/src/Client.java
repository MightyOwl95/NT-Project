import java.io.*;
import java.net.*;

public class Client {
	public static void main(String x[]) throws UnknownHostException, IOException {
		int port = 6000;
		Socket s = new Socket("192.168.0.134", port);
		PrintStream PS = new PrintStream(s.getOutputStream());
		PS.println("Hello Server from Client");
		InputStreamReader ir = new InputStreamReader(s.getInputStream());
		BufferedReader br = new BufferedReader(ir);
		String message = br.readLine();
		System.out.println(message);

		while (true) {

			if (message.equals("BYE") || message.equals("QUIT")) {
				System.out.println("m3 el salama ya zengy");
				s.close();
				break;
			}
		}

		/*
		 * if (message == "BYE" || message == "QUIT") { System.out.println(
		 * "Server Closing."); s.close(); }
		 */
	}
}