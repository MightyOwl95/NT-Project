import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server {
	public static void main(String[] args) throws IOException {
		int port = 6000;
		ServerSocket S1 = new ServerSocket(port);

		Socket SS = S1.accept();
		InputStreamReader isr = new InputStreamReader(SS.getInputStream());
		Scanner SC = new Scanner(isr);

		System.out.println("Server connected");

		String message = SC.nextLine();
		System.out.println(message);

		while (true) {
			if (message != null) {
				PrintStream ps = new PrintStream(SS.getOutputStream());
				ps.println("Wasaleet !!!!");
			}

			if (message.equals("BYE") || message.equals("QUIT")) {
				System.out.println("m3 el salama ya zengy");
				SC.close();
				SS.close();
				S1.close();
				break;
			}
		}
	}
}
